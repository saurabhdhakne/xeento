# Getting Started

This is the onboarding page.

![Team photo](Getting Started b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5/team.png)

- Set up your laptop
- Read the [Roadmap](Roadmap c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6.md)
- Say hi on Slack
